import os
import time
import binascii
from datetime import datetime

LOG_PATH = "/tmp/ssl_intercept.log"

def hexdump(data):
    # Función para mostrar hex y ascii al lado, como en Wireshark/mitmproxy
    try:
        hex_part = binascii.hexlify(data.encode('latin1', 'replace')).decode()
        readable = "".join([c if 32 <= ord(c) <= 126 else "." for c in data])
        return f"{hex_part[:40]}... | {readable[:30]}"
    except:
        return "[Error al procesar binario]"

def analyze_traffic():
    print(f"[*] Analizador Forense de Memoria (DNS-over-TLS) iniciado...")
    print(f"[*] Monitoreando: {LOG_PATH}\n" + "-"*70)

    if not os.path.exists(LOG_PATH):
        open(LOG_PATH, 'a').close()

    try:
        f = open(LOG_PATH, 'r', errors='replace')
        f.seek(0, 2)
        
        while True:
            line = f.readline()
            if not line:
                time.sleep(0.1)
                continue

            timestamp = datetime.now().strftime("%H:%M:%S")
            
            if "[SENT ]" in line:
                direction = "\033[91m[SENT]\033[0m"
                raw_data = line.replace("[SENT ]   ", "").strip()
                print(f"[{timestamp}] {direction} {hexdump(raw_data)}")
            elif "[RECV ]" in line:
                direction = "\033[92m[RECV]\033[0m"
                raw_data = line.replace("[RECV ]   ", "").strip()
                print(f"[{timestamp}] {direction} {hexdump(raw_data)}")
                    
    except KeyboardInterrupt:
        print("\n[*] Fin del análisis.")

if __name__ == "__main__":
    analyze_traffic()
