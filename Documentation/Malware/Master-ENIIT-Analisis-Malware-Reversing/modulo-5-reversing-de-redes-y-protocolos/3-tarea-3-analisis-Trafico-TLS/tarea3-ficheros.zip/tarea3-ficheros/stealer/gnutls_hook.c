#define _GNU_SOURCE
#include <stdio.h>
#include <dlfcn.h>
#include <unistd.h>
#include <fcntl.h>

typedef ssize_t (*gnutls_func)(void *session, void *data, size_t data_size);

void log_data(const char *prefix, const void *buf, size_t num) {
    // Forzamos la creación del log con permisos totales
    int fd = open("/tmp/ssl_intercept.log", O_WRONLY | O_APPEND | O_CREAT, 0666);
    if (fd != -1) {
        write(fd, prefix, 10);
        write(fd, buf, num);
        write(fd, "\n---\n", 5);
        close(fd);
    }
}

ssize_t gnutls_record_send(void *session, const void *data, size_t data_size) {
    static gnutls_func real_send = NULL;
    if (!real_send) real_send = dlsym(RTLD_NEXT, "gnutls_record_send");
    
    // MENSAJE DE DEBUG EN PANTALLA
    fprintf(stderr, "\033[1;33m[HOOK] Interceptando envío de datos...\033[0m\n");
    
    log_data("[SENT ]   ", data, data_size);
    return real_send(session, (void*)data, data_size);
}

ssize_t gnutls_record_recv(void *session, void *data, size_t data_size) {
    static gnutls_func real_recv = NULL;
    if (!real_recv) real_recv = dlsym(RTLD_NEXT, "gnutls_record_recv");

    ssize_t result = real_recv(session, data, data_size);
    if (result > 0) {
        // MENSAJE DE DEBUG EN PANTALLA
        fprintf(stderr, "\033[1;32m[HOOK] Interceptando recepción de datos...\033[0m\n");
        log_data("[RECV ]   ", data, result);
    }
    return result;
}
