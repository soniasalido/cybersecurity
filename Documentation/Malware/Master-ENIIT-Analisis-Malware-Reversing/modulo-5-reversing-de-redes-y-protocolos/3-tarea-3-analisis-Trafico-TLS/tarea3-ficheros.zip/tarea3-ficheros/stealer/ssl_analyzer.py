import os
import sys
import time
from datetime import datetime

# Ruta del archivo o FIFO generada por el Hook en C
LOG_PATH = "/tmp/ssl_intercept.log"

def analyze_traffic():
    print(f"[*] Iniciando análisis de tráfico SSL/TLS descifrado...")
    print(f"[*] Monitoreando: {LOG_PATH}\n" + "-"*60)

    # Verificamos si el archivo existe antes de empezar
    if not os.path.exists(LOG_PATH):
        # Si es un fichero, lo creamos; si es FIFO, esperamos a que el Hook lo abra
        open(LOG_PATH, 'a').close()

    try:
        with open(LOG_PATH, 'r', errors='replace') as f:
            # Ir al final del archivo si es un log persistente
            f.seek(0, 2)
            
            while True:
                line = f.readline()
                if not line:
                    time.sleep(0.1)  # Evitar consumo excesivo de CPU
                    continue

                # Parseo de metadatos
                timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]
                
                if "[WRITE]" in line:
                    direction = "\033[91m[SENT]\033[0m"  # Rojo para datos salientes
                    content = line.replace("[WRITE]   ", "").strip()
                elif "[READ ]" in line:
                    direction = "\033[92m[RECV]\033[0m"  # Verde para datos entrantes
                    content = line.replace("[READ ]   ", "").strip()
                else:
                    continue

                # Mostrar información formateada
                if content and content != "---":
                    print(f"[{timestamp}] {direction} | Data: {content[:100]}...")
                    
    except KeyboardInterrupt:
        print("\n[*] Análisis finalizado por el usuario.")
    except Exception as e:
        print(f"[-] Error: {e}")

if __name__ == "__main__":
    analyze_traffic()
