<html>
<head>
    
</head>

<body>
    <div class="form">
        <form action="sqli2.php" method="get">
            Artículo: <input type="text" name="articulo">
            <input type="submit">
    </div>
</body>

</html>
