<html>
<head>

</head>

<body>

    <?php
    if (isset($_GET["articulo"])) {
        //Como esto se implementa en un contenedor docker, el host no es localhost, sino el nombre del servicio: mysql
        $conexion = mysqli_connect('', 'root', '', 'demos')
        or die ("No se puede conectar con el servidor");

        $queEmp = "SELECT * FROM demos.articulos where Nombre ='" . $_GET["articulo"] . "'";

        $resEmp = mysqli_query($conexion, $queEmp) or die(mysqli_error());
        $totEmp = mysqli_num_rows($resEmp);

        if ($totEmp > 0) {
            echo '<div  class="table">';
            echo '<table>';
            echo "<tr><th>Artículo</th><th>Precio</th></tr>";
            while ($rowEmp = mysqli_fetch_assoc($resEmp)) {
                echo "<tr><td> " . $rowEmp['Nombre'] . "</td><td> " . $rowEmp['Precio'] . "</td></tr>";
            }
            echo '</table>';
            echo '</div>';
        } else {
            echo "Artículo no encontrado. :(";
        }
    }

    ?>


</body>

</html>
