<?php
//DB Params
define ("DB_HOST", "localhost");
define ("DB_USER", "root");
define ("DB_PASS", "");
define ("DB_NAME", "forum");

define("SITE_TITLE", "Bienvenido al foro!");

//Paths
define('BASE_URI','http://'.$_SERVER['SERVER_NAME'].':80/foro/');

