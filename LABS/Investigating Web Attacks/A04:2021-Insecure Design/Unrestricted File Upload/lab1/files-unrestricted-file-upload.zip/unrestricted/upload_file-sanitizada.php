<?php
  // Si se ha producido algún error al subir el fichero lo indicamos en pantalla mostrando el código de error
  if ($_FILES["file"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["file"]["error"] . "<br>";
    }
  else
    {
    // Si el fichero existe dentro de la carpeta upload, no lo subimos
    if (file_exists("upload/" . $_FILES["file"]["name"]))
      {
      echo $_FILES["file"]["name"] . " already exists. ";
      }
    else
      {
        // Comprobamos que el fichero sea una imagen o un PDF
        if (($_FILES["file"]["type"] == "image/jpeg" || $_FILES["file"]["type"] == "image/pjpeg" ||
            $_FILES["file"]["type"] == "image/png" || $_FILES["file"]["type"] == "image/gif" ||
            $_FILES["file"]["type"] == "application/pdf"))
        {
            // Comprobamos que el tamaño del fichero sea menor de 2MB
            if ($_FILES["file"]["size"] < 2000000)
            {
                // Comprobamos que el nombre del fichero sea válido.
                // Sólo se permiten letras, números, espacios, puntos y guiones bajos
                if (preg_match('/^[a-zA-Z0-9._ ]+$/' , $_FILES["file"]["name"]))
                {
                    move_uploaded_file($_FILES["file"]["tmp_name"],
                    "upload/" . $_FILES["file"]["name"]);
                    echo "Stored in: " . "upload/" . $_FILES["file"]["name"];
                }
                else
                {
                    echo "<script>alert('ERROR. Nombre de fichero no válido.');</script>";
                }
            }
            else
            {
                echo "<script>alert('ERROR. Tamaño de fichero no válido');</script>";
            }
        }
        else
        {
            echo "<script>alert('ERROR. Ficheros permitidos: extensiones para fotos & PDF');</script>";
        }
      }
    }
?>
